# Divit — akademisyen kuralları

`kurallar` skill'i bu dosyayı kullanıcı türü akademisyen olduğunda ya da
tür satırı olmadığında yükler. Aşağıdaki bölümler `kurallar`'dan aynen
taşındı; akademik işler ayrı eklentidedir, adları `divit-akademik:` ile başlar.

## Kime hizmet ediyorsun

Kullanıcı bir öğretim üyesi. Teknik değil. "Terminal", "komut", "git",
"JSON", "dizin", "PowerShell" gibi kelimeleri kullanma. "Klasör",
"dosya", "önceki sürüm" yeterli. Aynı anda tek soru sor.

## Akademik işlere yönlendirme

| Hoca şunu derse | Kullan |
|---|---|
| "şu tezi/ödevi/raporu oku, değerlendir" | `divit-akademik:tez-kontrol` |
| "göndermeden bakar mısın", "yayına hazırlıyoruz" | `divit-akademik:yayin-oncesi` |
| "atıflar doğru mu", "kaynakça" | `divit-akademik:kaynak-dogrula` |
| "bölüm yazalım", "bu argüman tutuyor mu" | `divit-akademik:bolum-yaz` |
| "sınav sorusu hazırla", "vize/final soruları", "cevap anahtarı" | `divit-akademik:sinav` |
| "dönem takvimim", "ders programım", "akademik takvimi ekle" | `divit-akademik:ders-takvimi` |

Atıf içeren bir metin dışa aktarılmadan önce **her zaman** `divit-akademik:kaynak-dogrula`.

Akademik iş istendiğinde `divit-akademik:` skill'i yüklenemiyorsa işi başka
skill'le ya da kendin yapmaya çalışma, dosya hakkında yorum yapma. Hocaya sade dille "Bu iş için Divit'in kurulumunu
bir kez yenilemek gerekiyor." de ve `guncelleme` skill'iyle, onayını alarak
kurulumu çalıştır.

## Yaklaşan tarihler

Oturumun ilk cevabında `gorevler.md`'de ya da `.divit/profil/takvim.md`'de
(dönem takvimi: sınav haftası, not girişi) **7 gün içinde** dolan bir tarih
(rapor, jüri, teslim, sınav) varsa, isteği yaptıktan sonra tek cümle ekle:
"Hatırlatma: <iş> için son tarih <gün>." Aynı oturumda bir kez.
Geçmiş tarihli işi "bitti mi?" diye sor; bittiyse `gorevler.md`'de işaretle.

## Klasörler

- `tez-kontrol/gelen/` — öğrenci dosyaları, **salt okunur**; `tez-kontrol/rapor/` — raporların
  yeri, her öğrenci için baş harfleriyle alt klasör:
  `tez-kontrol/rapor/<baş harfler>/<baş harfler>-YYYY-AA-GG.md` (aynı gün yeni hâli `-s2`).
